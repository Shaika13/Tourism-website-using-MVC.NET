﻿using AsiaTravels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AsiaTravels.Controllers
{
    public class ContactController : Controller
    {
        // GET: Contact
        public ActionResult contactform()
        {
            return View();
        }
        [HttpPost]
        public ActionResult contactform(contact con)
        {
            if (ModelState.IsValid)
            {
                using (travelEntities4 db = new travelEntities4())
                {

                    db.contacts.Add(con);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = " successfully sent";
            }
            return View();
        }
    }
}