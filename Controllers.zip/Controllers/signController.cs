﻿using AsiaTravels.Models;
using System.Linq;
using System.Web.Mvc;

namespace AsiaTravels.Controllers
{
    public class signController : Controller
    {
        // GET: sign
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Reg(user usr)
        {
            if (ModelState.IsValid)
            {
                using (travelEntities4 db = new travelEntities4())
                {

                    db.users.Add(usr);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = usr.Name + " successfully registered";
            }
            return View();
        }
        public ActionResult Login()
        {
            return View();

        }
        [HttpPost]
        public ActionResult log(user usr)
        {
            using (travelEntities4 db = new travelEntities4())
            {
                user us = db.users.Single(u => u.Email == usr.Email && u.Password == usr.Password);
                if (us != null)
                {
                    Session["Email"] = us.Email.ToString();
                    Session["Name"] = us.Name.ToString();
                    return RedirectToAction("Loggedin");

                }
                else
                {
                    ModelState.AddModelError("", "Wrong Info!");


                }
            }
            return View();
        }
        public ActionResult Loggedin()
        {
            if (Session["Email"] != null)
            {

                return View();

            }

            else
            {

                return RedirectToAction("Login");
               
            }
        }
        [HttpPost]
        public ActionResult Loggedin(booking book)
        {
            if (ModelState.IsValid)
            {
                using (travelEntities4 db = new travelEntities4())
                {

                    db.bookings.Add(book);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = " successfully booked";
            }
            return View();
        }

        public ActionResult Logout()
        {
            if (Session["Email"] != null)
            {
                Session["Email"] = null;
                Session["Name"] = null;
                Session.Clear();

                return RedirectToAction("Login");
            }
            else
            {

                return RedirectToAction("Register");
            }
        }
    }
}