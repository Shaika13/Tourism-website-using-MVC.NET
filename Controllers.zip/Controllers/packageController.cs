﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AsiaTravels.Controllers
{
    public class packageController : Controller
    {
        // GET: package
        public ActionResult viewpackage()
        {
            return View();
        }
        public ActionResult bookbutton()
        {
            return View();
        }
    }
}